import React, { Fragment } from 'react';
import { Link } from "gatsby"
import Image from "../components/images4"

import Card from 'react-bootstrap/Card';

//import data from '..data/data';

import './loa.css';

const ListOfAuthors = () => (
  <Fragment>
    <h1 className='center'>Hi from the listOfAuthors</h1>
    <p className='center'>Welcome to page listOfAuthors</p>  
    <div className='fl'>
  
      <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='1.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>

        <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='2.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>
  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='3.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>
  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='4.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>
  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='5.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>
  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='6.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>
  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='7.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>
  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='8.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>

  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='9.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>

  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='10.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>
  
  
  
          <Card style={{ width: '18rem' }}>
        <Card.Header>Featured</Card.Header>
          <div style={{ maxWidth: `18rem`, marginBottom: `1.45rem` }}>
            <Image imgName='11.jpg'/>
          </div>
        <Card.Body>
          <Card.Title>Special title treatment</Card.Title>
          <Card.Text>
            With supporting text below as a natural lead-in to additional content.
          </Card.Text>
        </Card.Body>
      </Card>
  

  
    </div>
    <Link to="/">Go back to the homepage</Link>
  

  </Fragment>
)

export default ListOfAuthors
