17-02-2020 - 1h list of authors page
18-02-2020 - 3h list of authors page
19-02-2020 - 5h list of authors page
